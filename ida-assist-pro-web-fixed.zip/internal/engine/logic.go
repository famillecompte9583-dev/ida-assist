
package engine

import "fmt"

var (
	FERRITINE_CUTOFF_NO_INFLAM = 45.0
	FERRITINE_CUTOFF_INFLAM    = 70.0
	TSAT_LOW                   = 20.0
)
func hasInflammation(crp *float64) bool { return crp != nil && *crp >= 5 }
func anemiaPresent(hb float64, sex string) (bool, string) {
	cut := 120.0; if sex == "M" { cut = 130.0 }
	ok := hb < cut
	return ok, fmt.Sprintf("Hb %.0f g/L (seuil %.0f) — anémie: %t (WHO 2020)", hb, cut, ok)
}
func diagnoseFerritin(ferr float64, crp *float64) (bool, string, string) {
	if hasInflammation(crp) { return ferr < FERRITINE_CUTOFF_INFLAM, fmt.Sprintf("CRP élevée → seuil OMS < %.0f µg/L", FERRITINE_CUTOFF_INFLAM), "WHO 2020/2023" }
	return ferr < FERRITINE_CUTOFF_NO_INFLAM, fmt.Sprintf("Ferritine < %.0f µg/L (AGA)", FERRITINE_CUTOFF_NO_INFLAM), "AGA 2020"
}
func diagnoseTSAT(tsat *float64) (bool, string) {
	if tsat == nil { return false, "TSAT absente" }
	return *tsat < TSAT_LOW, "TSAT < 20% (BSG 2021)"
}
func microSupport(mcv, mch float64) (bool, string) {
	ok := (mcv < 80) || (mch < 27)
	if ok { return true, "Microcytose/hypochromie compatibles (BSG 2021)" }
	return false, "Pas de microcytose/hypochromie"
}
func Evaluate(p InputPatient) Report {
	rep := Report{}
	ana, msgA := anemiaPresent(p.Bio.Hb_gL, p.Sexe)
	okF, msgF, refF := diagnoseFerritin(p.Bio.Ferritine_ugL, p.Bio.CRP_mgL)
	okT, msgT := diagnoseTSAT(p.Bio.TSAT_pct)
	okM, msgM := microSupport(p.Bio.MCV_fL, p.Bio.MCH_pg)
	rep.SummaryOK = okF || okT
	rep.Messages = []RuleHit{{msgA,"WHO 2020"},{msgF,refF},{msgT,"BSG 2021"},{msgM,"BSG 2021"}}
	// etiologies
	var et [][4]string
	if p.Sexe=="F" && (p.Menopause==nil || !*p.Menopause) { s:=0; switch p.Pertes.Menorragies{case "severe":s=85;case "moderee":s=70;case "legere":s=20} ; if s>0 { et=append(et,[4]string{"Pertes gynécologiques",fmt.Sprintf("%d",s),"Ménorragies","BSG 2021"}) } }
	base:=35; if p.Sexe=="M" || (p.Sexe=="F" && p.Menopause!=nil && *p.Menopause){base=60}
	et=append(et,[4]string{"Source digestive occulte",fmt.Sprintf("%d",base),"Profil épidémiologique","AGA 2020, BSG 2021"})
	if p.Tests.Gastro.OGD=="anormal" || p.Tests.Gastro.Coloscopie=="anormal" { et=append(et,[4]string{"Saignement digestif", "85","Anomalie endoscopique","AGA 2020"}) }
	if p.Tests.Celiac.TTG_IgA=="pos" { et=append(et,[4]string{"Maladie cœliaque","90","Sérologie positive","Celiac 2023"}) } else { et=append(et,[4]string{"Maladie cœliaque (à dépister)","55","Dépistage recommandé","Celiac 2023"}) }
	if p.Tests.HPylori=="pos" { et=append(et,[4]string{"Gastrite H. pylori","70","Association à IDA","AGA 2020, BSG 2021"}) } else if p.Tests.HPylori=="non_fait" { et=append(et,[4]string{"H. pylori (à rechercher)","45","IDA inexpliquée","AGA 2020"}) }
	if p.Dietetique.ApportsFer=="faibles" || p.Dietetique.Vegetarien { et=append(et,[4]string{"Apports insuffisants","40","Apports faibles/végétarisme","BSG 2021"}) }
	for _,a:=range p.ATCD{ if a=="bypass gastrique"{ et=append(et,[4]string{"Séquelle bariatrique","65","ATCD","BSG 2021"}) } }
	for _,m:=range p.Medications{ if m=="IPP"{ et=append(et,[4]string{"Hypochlorhydrie/IPP","35","IPP au long cours","BSG 2021"}) } }
	rep.Etiologies = et
	// checklist
	done,missing:=[]string{},[]string{}
	if p.Tests.Gastro.OGD!="non_fait"{done=append(done,"OGD")}else{missing=append(missing,"OGD")}
	if p.Tests.Gastro.Coloscopie!="non_fait"{done=append(done,"Coloscopie")}else{missing=append(missing,"Coloscopie")}
	if p.Tests.Capsule!="non_fait"{done=append(done,"Capsule endoscopique")}
	if !(p.Tests.Celiac.TTG_IgA=="non_fait"||p.Tests.Celiac.IgA_total=="non_fait"){done=append(done,"Sérologie cœliaque")}else{missing=append(missing,"Sérologie cœliaque (tTG-IgA + IgA total)")}
	if p.Tests.HPylori!="non_fait"{done=append(done,"H. pylori")}else{missing=append(missing,"H. pylori")}
	if p.Tests.UrinesHematurie!="non_fait"{done=append(done,"Analyse d’urines (hématurie)")}else{missing=append(missing,"Analyse d’urines (hématurie)")}
	if p.Sexe=="F" && (p.Menopause==nil || !*p.Menopause){ if p.Tests.GynecoEval=="fait"{done=append(done,"Évaluation gynécologique")}else{missing=append(missing,"Évaluation gynécologique")} }
	rep.Done,rep.Missing=done,missing
	// recs
	recs:=[]Recommendation{}
	if p.Tests.Gastro.OGD=="non_fait"||p.Tests.Gastro.Coloscopie=="non_fait"{recs=append(recs,Recommendation{"Endoscopie bidirectionnelle (OGD + coloscopie)","Indiquée selon profil",[]string{"AGA 2020","BSG 2021"}})}
	if p.Tests.Gastro.OGD=="normal"&&p.Tests.Gastro.Coloscopie=="normal"&&p.Tests.Capsule=="non_fait"{recs=append(recs,Recommendation{"Capsule endoscopique (si IDA persistante)","Endoscopies négatives",[]string{"AGA 2020","AGA CPU 2024"}})}
	if p.Tests.Celiac.TTG_IgA=="non_fait"||p.Tests.Celiac.IgA_total=="non_fait"{recs=append(recs,Recommendation{"Sérologie cœliaque (tTG-IgA + IgA total)","Dépistage universel recommandé",[]string{"Celiac 2023"}})}
	if p.Tests.HPylori=="non_fait"{recs=append(recs,Recommendation{"Test H. pylori (soufflage/Ag fécal/biopsie)","IDA inexpliquée",[]string{"AGA 2020","BSG 2021"}})}
	recs=append(recs,Recommendation{"Éducation: fer oral vs IV; suivi Hb 2–4 sem puis ferritine 4–8 sem","Bonnes pratiques",[]string{"AGA CPU 2024"}})
	rep.Recs=recs
	if p.Pertes.SellesNoires { rep.RedFlags = append(rep.RedFlags, "Méléna/selles noires — URGENCE") }
	if p.Bio.Hb_gL < 80 { rep.RedFlags = append(rep.RedFlags, fmt.Sprintf("Hb très basse (%.0f g/L) — URGENCE", p.Bio.Hb_gL)) }
	rep.Bibliography = []string{"AGA 2020","AGA CPU 2024","BSG 2021","WHO 2020/2023","Celiac 2023"}
	return rep
}
