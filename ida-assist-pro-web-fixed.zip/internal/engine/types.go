
package engine

type Dietetique struct {
	ApportsFer string `json:"apports_fer"`
	Vegetarien bool   `json:"vegetarien"`
}
type Pertes struct {
	Menorragies  string `json:"menorragies"`
	SellesNoires bool   `json:"selles_noires"`
	Hematurie    bool   `json:"hematurie"`
}
type Bio struct {
	Hb_gL         float64  `json:"Hb_gL"`
	MCV_fL        float64  `json:"MCV_fL"`
	MCH_pg        float64  `json:"MCH_pg"`
	Ferritine_ugL float64  `json:"ferritine_ugL"`
	CRP_mgL       *float64 `json:"CRP_mgL"`
	TSAT_pct      *float64 `json:"TSAT_pct"`
	FerSerique    *float64 `json:"fer_serique"`
	STfR          *float64 `json:"sTfR"`
	ReticHb       *float64 `json:"reticulocyte_Hb"`
}
type Gastro struct { OGD string `json:"OGD"`; Coloscopie string `json:"coloscopie"` }
type Celiac struct { TTG_IgA string `json:"tTG_IgA"`; IgA_total string `json:"IgA_total"` }
type TestsRealises struct {
	FOBT string `json:"FOBT"`
	Gastro Gastro `json:"gastro"`
	Capsule string `json:"capsule"`
	HPylori string `json:"HPylori"`
	Celiac Celiac `json:"celiaque"`
	GynecoEval string `json:"gyneco_eval"`
	UrinesHematurie string `json:"urines_hematurie"`
}
type InputPatient struct {
	Age int `json:"age"`; Sexe string `json:"sexe"`; Menopause *bool `json:"menopause"`
	Symptomes []string `json:"symptomes"`; ATCD []string `json:"ATCD"`; Medications []string `json:"medications"`
	Dietetique Dietetique `json:"dietetique"`; Pertes Pertes `json:"pertes"`; Bio Bio `json:"bio"`
	Tests TestsRealises `json:"tests_realises"`; ResultDates map[string]string `json:"resultats_dates"`
}
type RuleHit struct { Text string `json:"text"`; Ref string `json:"ref"` }
type Recommendation struct { Title string `json:"title"`; Why string `json:"why"`; Refs []string `json:"refs"` }
type Report struct {
	SummaryOK bool `json:"summary_ok"`; Messages []RuleHit `json:"messages"`; Etiologies [][4]string `json:"etiologies"`
	Done []string `json:"done"`; Missing []string `json:"missing"`; Recs []Recommendation `json:"recs"`; RedFlags []string `json:"red_flags"`; Bibliography []string `json:"bibliography"`
}
