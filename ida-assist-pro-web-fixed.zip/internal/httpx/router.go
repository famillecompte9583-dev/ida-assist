
package httpx

import (
	"encoding/json"
	"html/template"
	"net/http"
	"sync"
	"idaassist/internal/engine"
	"idaassist/internal/render"
)

var last engine.Report
var mu sync.RWMutex

func NewMux() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("/", handleUI)
	mux.HandleFunc("/api/analyse", handleAnalyse)
	mux.HandleFunc("/api/export/md", handleExportMD)
	mux.HandleFunc("/api/export/pdf", handleExportPDF)
	mux.Handle("/static/", http.StripPrefix("/static/", http.FileServer(http.Dir("web/static"))))
	return mux
}

func handleUI(w http.ResponseWriter, r *http.Request) {
	tpl := template.Must(template.ParseFiles("web/templates/index.html"))
	tpl.Execute(w, nil)
}

func handleAnalyse(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost { http.Error(w, "Méthode non autorisée", http.StatusMethodNotAllowed); return }
	var in engine.InputPatient
	if err := json.NewDecoder(r.Body).Decode(&in); err != nil { http.Error(w, "JSON invalide: "+err.Error(), 400); return }
	rep := engine.Evaluate(in)
	mu.Lock(); last = rep; mu.Unlock()
	w.Header().Set("Content-Type","application/json; charset=utf-8")
	json.NewEncoder(w).Encode(rep)
}

func handleExportMD(w http.ResponseWriter, r *http.Request) {
	mu.RLock(); rep := last; mu.RUnlock()
	md := render.Markdown(rep)
	w.Header().Set("Content-Type","text/markdown; charset=utf-8")
	w.Header().Set("Content-Disposition","attachment; filename=rapport.md")
	w.Write([]byte(md))
}

func handleExportPDF(w http.ResponseWriter, r *http.Request) {
	mu.RLock(); rep := last; mu.RUnlock()
	pdf, err := render.PDF(rep)
	if err != nil { http.Error(w, "Erreur PDF: "+err.Error(), 500); return }
	w.Header().Set("Content-Type","application/pdf")
	w.Header().Set("Content-Disposition","attachment; filename=rapport.pdf")
	w.Write(pdf)
}
