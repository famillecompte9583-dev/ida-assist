
package render

import (
	"bytes"
	"fmt"
	"strings"

	"github.com/jung-kurt/gofpdf"
	"idaassist/internal/engine"
)

func Markdown(r engine.Report) string {
	b := &strings.Builder{}
	b.WriteString("# Rapport d’aide au raisonnement – Carence en fer (outil éducatif)\n\n")
	b.WriteString("**Avertissement** : cet outil n’émet pas de diagnostic ni de prescription; discuter tout résultat avec le/la médecin.\n\n")
	b.WriteString("## Résumé diagnostique\n")
	b.WriteString(fmt.Sprintf("- Indices compatibles avec carence en fer ? **%t**\n", r.SummaryOK))
	for _, m := range r.Messages { b.WriteString(fmt.Sprintf("- %s (%s)\n", m.Text, m.Ref)) }
	b.WriteString("\n## Causes probables\n")
	for _, e := range r.Etiologies { b.WriteString(fmt.Sprintf("- %s : **%s** — %s (%s)\n", e[0], e[1], e[2], e[3])) }
	b.WriteString("\n## Examens déjà réalisés & manquants\n")
	if len(r.Done)>0 { b.WriteString("**Faits** : "+strings.Join(r.Done, ", ")+"\n") } else { b.WriteString("**Faits** : —\n") }
	if len(r.Missing)>0 { b.WriteString("**Manquants** : "+strings.Join(r.Missing, ", ")+"\n") } else { b.WriteString("**Manquants** : —\n") }
	b.WriteString("\n## Prochaines étapes recommandées\n")
	for i, x := range r.Recs { b.WriteString(fmt.Sprintf("%d. %s — %s (%s)\n", i+1, x.Title, x.Why, strings.Join(x.Refs, ", "))) }
	if len(r.RedFlags)>0 { b.WriteString("\n> **URGENCE** : "+strings.Join(r.RedFlags, "; ")+"\n") }
	b.WriteString("\n## Bibliographie courte\n")
	for _, v := range r.Bibliography { b.WriteString("- "+v+"\n") }
	return b.String()
}

func PDF(r engine.Report) ([]byte, error) {
	p := gofpdf.New("P", "mm", "A4", "")
	p.AddPage()
	p.SetFont("Helvetica", "B", 16)
	p.Cell(0, 10, "Rapport – Carence en fer (outil éducatif)")
	p.Ln(12)

	p.SetFont("Helvetica", "", 11)
	write := func(title string, lines []string){
		p.SetFont("Helvetica", "B", 12); p.Cell(0,8,title); p.Ln(8)
		p.SetFont("Helvetica", "", 11)
		for _, ln := range lines {
			p.MultiCell(0,6, ln, "", "L", false)
		}
		p.Ln(2)
	}

	// Résumé
	lines := []string{fmt.Sprintf("Compatibilité carence en fer : %t", r.SummaryOK)}
	for _, m := range r.Messages { lines = append(lines, fmt.Sprintf("- %s (%s)", m.Text, m.Ref)) }
	write("Résumé diagnostique", lines)

	// Étiologies
	var et []string
	for _, e := range r.Etiologies { et = append(et, fmt.Sprintf("- %s : %s — %s (%s)", e[0], e[1], e[2], e[3])) }
	write("Causes probables", et)

	// Checklist
	write("Examens", []string{fmt.Sprintf("Faits : %v", strings.Join(r.Done,", ")), fmt.Sprintf("Manquants : %v", strings.Join(r.Missing,", "))})

	// Recommandations
	var recs []string
	for i, x := range r.Recs { recs = append(recs, fmt.Sprintf("%d. %s — %s (%s)", i+1, x.Title, x.Why, strings.Join(x.Refs, ", "))) }
	write("Prochaines étapes", recs)

	// Urgence
	if len(r.RedFlags)>0 { write("URGENCE", []string{strings.Join(r.RedFlags, "; ")}) }

	// Bibliographie
	write("Bibliographie", r.Bibliography)

	var buf bytes.Buffer
	err := p.Output(&buf)
	return buf.Bytes(), err
}
