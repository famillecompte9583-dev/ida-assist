
package main

import (
	"fmt"
	"log"
	"net/http"
	"time"
	"idaassist/internal/httpx"
)

func main() {
	mux := httpx.NewMux()
	srv := &http.Server{ Addr: ":8080", Handler: mux, ReadTimeout: 10*time.Second, WriteTimeout: 20*time.Second }
	fmt.Println("IDA Assist Pro — http://localhost:8080")
	log.Fatal(srv.ListenAndServe())
}
