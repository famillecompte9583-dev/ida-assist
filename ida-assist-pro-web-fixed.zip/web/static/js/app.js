
const formDiv = document.getElementById('form');
const rapportDiv = document.getElementById('rapport');

function field(label, id, type='text', attrs='') { return `<label for="${id}">${label}</label><input id="${id}" type="${type}" ${attrs}/>` }
function select(label,id,opts){return `<label for="${id}">${label}</label><select id="${id}">${opts.map(o=>`<option value="${o}">${o}</option>`).join('')}</select>`}
function checkbox(label,id){return `<label><input id="${id}" type="checkbox"/> ${label}</label>`}

formDiv.innerHTML = `
  ${field('Âge','age','number')}
  ${select('Sexe','sexe',['F','M'])}
  ${checkbox('Ménopausée','menopause')}
  <hr/>
  <label>Symptômes</label>
  <div class="chips">
    <label><input type="checkbox" name="sympt" value="fatigue"/> Fatigue</label>
    <label><input type="checkbox" name="sympt" value="pica"/> Pica</label>
    <label><input type="checkbox" name="sympt" value="dyspnee"/> Dyspnée</label>
  </div>
  <label>ATCD</label>
  <div class="chips">
    <label><input type="checkbox" name="atcd" value="bypass gastrique"/> Bypass</label>
    <label><input type="checkbox" name="atcd" value="MICI"/> MICI</label>
    <label><input type="checkbox" name="atcd" value="IRC"/> IRC</label>
    <label><input type="checkbox" name="atcd" value="don de sang"/> Don de sang</label>
  </div>
  <label>Médicaments</label>
  <div class="chips">
    <label><input type="checkbox" name="meds" value="IPP"/> IPP</label>
    <label><input type="checkbox" name="meds" value="AINS"/> AINS</label>
    <label><input type="checkbox" name="meds" value="anticoagulant"/> Anticoagulant</label>
  </div>
  ${select('Apports en fer','apports_fer',['adequats','faibles'])}
  ${checkbox('Végétarien','vegetarien')}
  ${select('Ménorragies','menorragies',['aucune','legere','moderee','severe'])}
  ${checkbox('Selles noires','selles_noires')}
  ${checkbox('Hématurie','hematurie')}
  <hr/>
  ${field('Hb (g/L)','hb','number')}
  ${field('MCV (fL)','mcv','number')}
  ${field('MCH (pg)','mch','number')}
  ${field('Ferritine (µg/L)','ferritine','number')}
  ${field('CRP (mg/L)','crp','number')}
  ${field('TSAT (%)','tsat','number')}
  ${field('Fer sérique','fer','number')}
  <hr/>
  ${select('FOBT','fobt',['neg','pos','non_fait'])}
  ${select('OGD','ogd',['non_fait','normal','anormal'])}
  ${select('Coloscopie','coloscopie',['non_fait','normal','anormal'])}
  ${select('Capsule','capsule',['non_fait','normal','anormal'])}
  ${select('H. pylori','hpylori',['non_fait','neg','pos'])}
  ${select('tTG-IgA','ttg',['non_fait','neg','pos'])}
  ${select('IgA total','iga',['non_fait','normal','bas'])}
  ${select('Évaluation gynéco','gyneco',['non_fait','fait'])}
  ${select('Urines (hématurie)','urines',['non_fait','neg','pos'])}
`;

document.getElementById('btn-analyse').onclick = async () => {
  const data = {
    age: parseInt(document.getElementById('age').value||0),
    sexe: document.getElementById('sexe').value,
    menopause: document.getElementById('menopause').checked,
    symptomes: Array.from(document.querySelectorAll('input[name="sympt"]:checked')).map(e=>e.value),
    ATCD: Array.from(document.querySelectorAll('input[name="atcd"]:checked')).map(e=>e.value),
    medications: Array.from(document.querySelectorAll('input[name="meds"]:checked')).map(e=>e.value),
    dietetique: { apports_fer: document.getElementById('apports_fer').value, vegetarien: document.getElementById('vegetarien').checked },
    pertes: { menorragies: document.getElementById('menorragies').value, selles_noires: document.getElementById('selles_noires').checked, hematurie: document.getElementById('hematurie').checked },
    bio: {
      Hb_gL: parseFloat(document.getElementById('hb').value||0),
      MCV_fL: parseFloat(document.getElementById('mcv').value||0),
      MCH_pg: parseFloat(document.getElementById('mch').value||0),
      ferritine_ugL: parseFloat(document.getElementById('ferritine').value||0),
      CRP_mgL: parseFloat(document.getElementById('crp').value||0),
      TSAT_pct: parseFloat(document.getElementById('tsat').value||0),
      fer_serique: parseFloat(document.getElementById('fer').value||0),
      sTfR: null, reticulocyte_Hb: null
    },
    tests_realises: {
      FOBT: document.getElementById('fobt').value,
      gastro: { OGD: document.getElementById('ogd').value, coloscopie: document.getElementById('coloscopie').value },
      capsule: document.getElementById('capsule').value,
      HPylori: document.getElementById('hpylori').value,
      coeliaque: { tTG_IgA: document.getElementById('ttg').value, IgA_total: document.getElementById('iga').value },
      gyneco_eval: document.getElementById('gyneco').value,
      urines_hematurie: document.getElementById('urines').value
    },
    resultats_dates: {}
  };

  const res = await fetch('/api/analyse', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data) });
  if(!res.ok){ rapportDiv.innerHTML = '<span class="badge danger">Erreur</span>'; return; }
  const rep = await res.json();
  rapportDiv.innerHTML = renderReport(rep);
};

function renderReport(r){
  let html = '';
  html += `<p>Compatibilité carence en fer : <span class="badge ${r.summary_ok ? 'ok':'warn'}">${r.summary_ok ? 'Probable' : 'À confirmer'}</span></p>`;
  html += '<h3>Règles appliquées</h3><ul>' + r.messages.map(m=>`<li>${m.text} <small>(${m.ref})</small></li>`).join('') + '</ul>';
  html += '<h3>Causes probables</h3><table class="table"><tr><th>Cause</th><th>Score</th><th>Arguments</th><th>Réfs</th></tr>' + r.etiologies.map(e=>`<tr><td>${e[0]}</td><td>${e[1]}</td><td>${e[2]}</td><td>${e[3]}</td></tr>`).join('') + '</table>';
  html += `<h3>Examens faits</h3><p>${r.done && r.done.length ? r.done.join(', ') : '—'}</p>`;
  html += `<h3>Manquants</h3><p>${r.missing && r.missing.length ? r.missing.join(', ') : '—'}</p>`;
  html += '<h3>Prochaines étapes</h3><ol>' + r.recs.map(x=>`<li>${x.title} — ${x.why} <small>(${x.refs.join(', ')})</small></li>`).join('') + '</ol>';
  if(r.red_flags && r.red_flags.length){ html += `<p><span class="badge danger">URGENCE</span> ${r.red_flags.join('; ')}</p>`; }
  html += '<h3>Bibliographie</h3><ul>' + r.bibliography.map(b=>`<li>${b}</li>`).join('') + '</ul>';
  return html;
}
